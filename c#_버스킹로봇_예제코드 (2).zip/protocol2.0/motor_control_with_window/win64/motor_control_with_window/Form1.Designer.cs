﻿namespace motor_control_with_window
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonPortConnet = new System.Windows.Forms.Button();
            this.textBoxOpenPort = new System.Windows.Forms.TextBox();
            this.textBoxBaudrate = new System.Windows.Forms.TextBox();
            this.textBoxC1 = new System.Windows.Forms.TextBox();
            this.labelOpenPort = new System.Windows.Forms.Label();
            this.labelBaudrate = new System.Windows.Forms.Label();
            this.labelConnect = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.LabelMortorGoalPosition = new System.Windows.Forms.Label();
            this.LabelMotorPresentPosition = new System.Windows.Forms.Label();
            this.LabelMotorNumber = new System.Windows.Forms.Label();
            this.textBoxC2 = new System.Windows.Forms.TextBox();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.textBoxC3 = new System.Windows.Forms.TextBox();
            this.textBoxC4 = new System.Windows.Forms.TextBox();
            this.textBoxC5 = new System.Windows.Forms.TextBox();
            this.textBoxC6 = new System.Windows.Forms.TextBox();
            this.textBoxC7 = new System.Windows.Forms.TextBox();
            this.textBoxC9 = new System.Windows.Forms.TextBox();
            this.textBoxC10 = new System.Windows.Forms.TextBox();
            this.textBoxC11 = new System.Windows.Forms.TextBox();
            this.textBoxC12 = new System.Windows.Forms.TextBox();
            this.LabelNo4 = new System.Windows.Forms.Label();
            this.textBoxPP4 = new System.Windows.Forms.TextBox();
            this.textBoxGP4 = new System.Windows.Forms.TextBox();
            this.trackBar4 = new System.Windows.Forms.TrackBar();
            this.LabelNo6 = new System.Windows.Forms.Label();
            this.textBoxPP6 = new System.Windows.Forms.TextBox();
            this.textBoxGP6 = new System.Windows.Forms.TextBox();
            this.trackBar6 = new System.Windows.Forms.TrackBar();
            this.LabelNo5 = new System.Windows.Forms.Label();
            this.textBoxPP5 = new System.Windows.Forms.TextBox();
            this.textBoxGP5 = new System.Windows.Forms.TextBox();
            this.trackBar5 = new System.Windows.Forms.TrackBar();
            this.LabelNo9 = new System.Windows.Forms.Label();
            this.textBoxPP9 = new System.Windows.Forms.TextBox();
            this.textBoxGP9 = new System.Windows.Forms.TextBox();
            this.trackBar9 = new System.Windows.Forms.TrackBar();
            this.textBoxPP8 = new System.Windows.Forms.TextBox();
            this.textBoxGP8 = new System.Windows.Forms.TextBox();
            this.trackBar8 = new System.Windows.Forms.TrackBar();
            this.LabelNo7 = new System.Windows.Forms.Label();
            this.textBoxPP7 = new System.Windows.Forms.TextBox();
            this.textBoxGP7 = new System.Windows.Forms.TextBox();
            this.trackBar7 = new System.Windows.Forms.TrackBar();
            this.LabelNo12 = new System.Windows.Forms.Label();
            this.textBoxPP12 = new System.Windows.Forms.TextBox();
            this.textBoxGP12 = new System.Windows.Forms.TextBox();
            this.trackBar12 = new System.Windows.Forms.TrackBar();
            this.LabelNo11 = new System.Windows.Forms.Label();
            this.textBoxPP11 = new System.Windows.Forms.TextBox();
            this.textBoxGP11 = new System.Windows.Forms.TextBox();
            this.trackBar11 = new System.Windows.Forms.TrackBar();
            this.LabelNo10 = new System.Windows.Forms.Label();
            this.textBoxPP10 = new System.Windows.Forms.TextBox();
            this.textBoxGP10 = new System.Windows.Forms.TextBox();
            this.trackBar10 = new System.Windows.Forms.TrackBar();
            this.textBoxC8 = new System.Windows.Forms.TextBox();
            this.LabelNo1 = new System.Windows.Forms.Label();
            this.LabelNo2 = new System.Windows.Forms.Label();
            this.LabelNo3 = new System.Windows.Forms.Label();
            this.LabelNo8 = new System.Windows.Forms.Label();
            this.textBoxGP3 = new System.Windows.Forms.TextBox();
            this.textBoxGP2 = new System.Windows.Forms.TextBox();
            this.textBoxGP1 = new System.Windows.Forms.TextBox();
            this.textBoxPP3 = new System.Windows.Forms.TextBox();
            this.textBoxPP2 = new System.Windows.Forms.TextBox();
            this.textBoxPP1 = new System.Windows.Forms.TextBox();
            this.buttonBulkWritePosition = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar10)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonPortConnet
            // 
            this.buttonPortConnet.Location = new System.Drawing.Point(209, 20);
            this.buttonPortConnet.Name = "buttonPortConnet";
            this.buttonPortConnet.Size = new System.Drawing.Size(75, 25);
            this.buttonPortConnet.TabIndex = 0;
            this.buttonPortConnet.Text = "포트 연결";
            this.buttonPortConnet.UseVisualStyleBackColor = true;
            this.buttonPortConnet.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxOpenPort
            // 
            this.textBoxOpenPort.Location = new System.Drawing.Point(37, 104);
            this.textBoxOpenPort.Multiline = true;
            this.textBoxOpenPort.Name = "textBoxOpenPort";
            this.textBoxOpenPort.ReadOnly = true;
            this.textBoxOpenPort.Size = new System.Drawing.Size(198, 114);
            this.textBoxOpenPort.TabIndex = 2;
            // 
            // textBoxBaudrate
            // 
            this.textBoxBaudrate.Location = new System.Drawing.Point(37, 263);
            this.textBoxBaudrate.Multiline = true;
            this.textBoxBaudrate.Name = "textBoxBaudrate";
            this.textBoxBaudrate.ReadOnly = true;
            this.textBoxBaudrate.Size = new System.Drawing.Size(198, 115);
            this.textBoxBaudrate.TabIndex = 3;
            // 
            // textBoxC1
            // 
            this.textBoxC1.Location = new System.Drawing.Point(264, 96);
            this.textBoxC1.Multiline = true;
            this.textBoxC1.Name = "textBoxC1";
            this.textBoxC1.ReadOnly = true;
            this.textBoxC1.Size = new System.Drawing.Size(260, 35);
            this.textBoxC1.TabIndex = 4;
            // 
            // labelOpenPort
            // 
            this.labelOpenPort.AutoSize = true;
            this.labelOpenPort.Location = new System.Drawing.Point(35, 85);
            this.labelOpenPort.Name = "labelOpenPort";
            this.labelOpenPort.Size = new System.Drawing.Size(39, 12);
            this.labelOpenPort.TabIndex = 6;
            this.labelOpenPort.Text = "OPEN";
            // 
            // labelBaudrate
            // 
            this.labelBaudrate.AutoSize = true;
            this.labelBaudrate.Location = new System.Drawing.Point(35, 232);
            this.labelBaudrate.Name = "labelBaudrate";
            this.labelBaudrate.Size = new System.Drawing.Size(69, 12);
            this.labelBaudrate.TabIndex = 7;
            this.labelBaudrate.Text = "BAUDRATE";
            // 
            // labelConnect
            // 
            this.labelConnect.AutoSize = true;
            this.labelConnect.Location = new System.Drawing.Point(351, 81);
            this.labelConnect.Name = "labelConnect";
            this.labelConnect.Size = new System.Drawing.Size(66, 12);
            this.labelConnect.TabIndex = 8;
            this.labelConnect.Text = "CONNECT";
            // 
            // trackBar1
            // 
            this.trackBar1.Enabled = false;
            this.trackBar1.Location = new System.Drawing.Point(677, 111);
            this.trackBar1.Maximum = 2800;
            this.trackBar1.Minimum = 900;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(201, 45);
            this.trackBar1.TabIndex = 16;
            this.trackBar1.Value = 900;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // LabelMortorGoalPosition
            // 
            this.LabelMortorGoalPosition.AutoSize = true;
            this.LabelMortorGoalPosition.Location = new System.Drawing.Point(743, 85);
            this.LabelMortorGoalPosition.Name = "LabelMortorGoalPosition";
            this.LabelMortorGoalPosition.Size = new System.Drawing.Size(85, 12);
            this.LabelMortorGoalPosition.TabIndex = 18;
            this.LabelMortorGoalPosition.Text = "목표 모터 위치";
            // 
            // LabelMotorPresentPosition
            // 
            this.LabelMotorPresentPosition.AutoSize = true;
            this.LabelMotorPresentPosition.Location = new System.Drawing.Point(877, 85);
            this.LabelMotorPresentPosition.Name = "LabelMotorPresentPosition";
            this.LabelMotorPresentPosition.Size = new System.Drawing.Size(85, 12);
            this.LabelMotorPresentPosition.TabIndex = 19;
            this.LabelMotorPresentPosition.Text = "실재 모터 위치";
            // 
            // LabelMotorNumber
            // 
            this.LabelMotorNumber.AutoSize = true;
            this.LabelMotorNumber.Location = new System.Drawing.Point(600, 96);
            this.LabelMotorNumber.Name = "LabelMotorNumber";
            this.LabelMotorNumber.Size = new System.Drawing.Size(57, 12);
            this.LabelMotorNumber.TabIndex = 20;
            this.LabelMotorNumber.Text = "모터 번호";
            // 
            // textBoxC2
            // 
            this.textBoxC2.Location = new System.Drawing.Point(264, 138);
            this.textBoxC2.Multiline = true;
            this.textBoxC2.Name = "textBoxC2";
            this.textBoxC2.ReadOnly = true;
            this.textBoxC2.Size = new System.Drawing.Size(260, 34);
            this.textBoxC2.TabIndex = 22;
            // 
            // trackBar2
            // 
            this.trackBar2.Enabled = false;
            this.trackBar2.Location = new System.Drawing.Point(677, 148);
            this.trackBar2.Maximum = 2900;
            this.trackBar2.Minimum = 1800;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(201, 45);
            this.trackBar2.TabIndex = 25;
            this.trackBar2.Value = 1800;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // trackBar3
            // 
            this.trackBar3.Enabled = false;
            this.trackBar3.Location = new System.Drawing.Point(677, 188);
            this.trackBar3.Maximum = 3000;
            this.trackBar3.Minimum = 1200;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(201, 45);
            this.trackBar3.TabIndex = 29;
            this.trackBar3.Value = 1200;
            this.trackBar3.Scroll += new System.EventHandler(this.trackBar3_Scroll);
            // 
            // textBoxC3
            // 
            this.textBoxC3.Location = new System.Drawing.Point(264, 178);
            this.textBoxC3.Multiline = true;
            this.textBoxC3.Name = "textBoxC3";
            this.textBoxC3.ReadOnly = true;
            this.textBoxC3.Size = new System.Drawing.Size(260, 34);
            this.textBoxC3.TabIndex = 31;
            // 
            // textBoxC4
            // 
            this.textBoxC4.Location = new System.Drawing.Point(264, 222);
            this.textBoxC4.Multiline = true;
            this.textBoxC4.Name = "textBoxC4";
            this.textBoxC4.ReadOnly = true;
            this.textBoxC4.Size = new System.Drawing.Size(260, 34);
            this.textBoxC4.TabIndex = 32;
            // 
            // textBoxC5
            // 
            this.textBoxC5.Location = new System.Drawing.Point(264, 263);
            this.textBoxC5.Multiline = true;
            this.textBoxC5.Name = "textBoxC5";
            this.textBoxC5.ReadOnly = true;
            this.textBoxC5.Size = new System.Drawing.Size(260, 34);
            this.textBoxC5.TabIndex = 33;
            // 
            // textBoxC6
            // 
            this.textBoxC6.Location = new System.Drawing.Point(264, 344);
            this.textBoxC6.Multiline = true;
            this.textBoxC6.Name = "textBoxC6";
            this.textBoxC6.ReadOnly = true;
            this.textBoxC6.Size = new System.Drawing.Size(260, 34);
            this.textBoxC6.TabIndex = 34;
            // 
            // textBoxC7
            // 
            this.textBoxC7.Location = new System.Drawing.Point(264, 395);
            this.textBoxC7.Multiline = true;
            this.textBoxC7.Name = "textBoxC7";
            this.textBoxC7.ReadOnly = true;
            this.textBoxC7.Size = new System.Drawing.Size(260, 34);
            this.textBoxC7.TabIndex = 35;
            // 
            // textBoxC9
            // 
            this.textBoxC9.Location = new System.Drawing.Point(264, 491);
            this.textBoxC9.Multiline = true;
            this.textBoxC9.Name = "textBoxC9";
            this.textBoxC9.ReadOnly = true;
            this.textBoxC9.Size = new System.Drawing.Size(260, 34);
            this.textBoxC9.TabIndex = 37;
            // 
            // textBoxC10
            // 
            this.textBoxC10.Location = new System.Drawing.Point(264, 538);
            this.textBoxC10.Multiline = true;
            this.textBoxC10.Name = "textBoxC10";
            this.textBoxC10.ReadOnly = true;
            this.textBoxC10.Size = new System.Drawing.Size(260, 34);
            this.textBoxC10.TabIndex = 38;
            // 
            // textBoxC11
            // 
            this.textBoxC11.Location = new System.Drawing.Point(264, 611);
            this.textBoxC11.Multiline = true;
            this.textBoxC11.Name = "textBoxC11";
            this.textBoxC11.ReadOnly = true;
            this.textBoxC11.Size = new System.Drawing.Size(260, 34);
            this.textBoxC11.TabIndex = 39;
            // 
            // textBoxC12
            // 
            this.textBoxC12.Location = new System.Drawing.Point(264, 653);
            this.textBoxC12.Multiline = true;
            this.textBoxC12.Name = "textBoxC12";
            this.textBoxC12.ReadOnly = true;
            this.textBoxC12.Size = new System.Drawing.Size(260, 34);
            this.textBoxC12.TabIndex = 40;
            // 
            // LabelNo4
            // 
            this.LabelNo4.AutoSize = true;
            this.LabelNo4.Location = new System.Drawing.Point(600, 238);
            this.LabelNo4.Name = "LabelNo4";
            this.LabelNo4.Size = new System.Drawing.Size(57, 24);
            this.LabelNo4.TabIndex = 44;
            this.LabelNo4.Text = "NO 4 :\r\n1800 2900";
            this.LabelNo4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP4
            // 
            this.textBoxPP4.Location = new System.Drawing.Point(902, 235);
            this.textBoxPP4.Name = "textBoxPP4";
            this.textBoxPP4.ReadOnly = true;
            this.textBoxPP4.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP4.TabIndex = 42;
            this.textBoxPP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP4
            // 
            this.textBoxGP4.Location = new System.Drawing.Point(751, 256);
            this.textBoxGP4.Name = "textBoxGP4";
            this.textBoxGP4.ReadOnly = true;
            this.textBoxGP4.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP4.TabIndex = 41;
            this.textBoxGP4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar4
            // 
            this.trackBar4.Enabled = false;
            this.trackBar4.Location = new System.Drawing.Point(677, 232);
            this.trackBar4.Maximum = 2900;
            this.trackBar4.Minimum = 1800;
            this.trackBar4.Name = "trackBar4";
            this.trackBar4.Size = new System.Drawing.Size(201, 45);
            this.trackBar4.TabIndex = 43;
            this.trackBar4.Value = 1800;
            this.trackBar4.Scroll += new System.EventHandler(this.trackBar4_Scroll);
            // 
            // LabelNo6
            // 
            this.LabelNo6.AutoSize = true;
            this.LabelNo6.Location = new System.Drawing.Point(600, 338);
            this.LabelNo6.Name = "LabelNo6";
            this.LabelNo6.Size = new System.Drawing.Size(57, 24);
            this.LabelNo6.TabIndex = 52;
            this.LabelNo6.Text = "NO 6 :\r\n1500 3000";
            this.LabelNo6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP6
            // 
            this.textBoxPP6.Location = new System.Drawing.Point(901, 335);
            this.textBoxPP6.Name = "textBoxPP6";
            this.textBoxPP6.ReadOnly = true;
            this.textBoxPP6.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP6.TabIndex = 50;
            this.textBoxPP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP6
            // 
            this.textBoxGP6.Location = new System.Drawing.Point(751, 356);
            this.textBoxGP6.Name = "textBoxGP6";
            this.textBoxGP6.ReadOnly = true;
            this.textBoxGP6.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP6.TabIndex = 49;
            this.textBoxGP6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar6
            // 
            this.trackBar6.Enabled = false;
            this.trackBar6.Location = new System.Drawing.Point(677, 332);
            this.trackBar6.Maximum = 3000;
            this.trackBar6.Minimum = 1500;
            this.trackBar6.Name = "trackBar6";
            this.trackBar6.Size = new System.Drawing.Size(201, 45);
            this.trackBar6.TabIndex = 51;
            this.trackBar6.Value = 1500;
            this.trackBar6.Scroll += new System.EventHandler(this.trackBar6_Scroll);
            // 
            // LabelNo5
            // 
            this.LabelNo5.AutoSize = true;
            this.LabelNo5.Location = new System.Drawing.Point(600, 279);
            this.LabelNo5.Name = "LabelNo5";
            this.LabelNo5.Size = new System.Drawing.Size(57, 24);
            this.LabelNo5.TabIndex = 48;
            this.LabelNo5.Text = "NO 5 :\r\n1700 3700";
            this.LabelNo5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP5
            // 
            this.textBoxPP5.Location = new System.Drawing.Point(901, 276);
            this.textBoxPP5.Name = "textBoxPP5";
            this.textBoxPP5.ReadOnly = true;
            this.textBoxPP5.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP5.TabIndex = 46;
            this.textBoxPP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP5
            // 
            this.textBoxGP5.Location = new System.Drawing.Point(751, 297);
            this.textBoxGP5.Name = "textBoxGP5";
            this.textBoxGP5.ReadOnly = true;
            this.textBoxGP5.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP5.TabIndex = 45;
            this.textBoxGP5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar5
            // 
            this.trackBar5.Enabled = false;
            this.trackBar5.Location = new System.Drawing.Point(677, 273);
            this.trackBar5.Maximum = 3700;
            this.trackBar5.Minimum = 1700;
            this.trackBar5.Name = "trackBar5";
            this.trackBar5.Size = new System.Drawing.Size(201, 45);
            this.trackBar5.TabIndex = 47;
            this.trackBar5.Value = 1700;
            this.trackBar5.Scroll += new System.EventHandler(this.trackBar5_Scroll);
            // 
            // LabelNo9
            // 
            this.LabelNo9.AutoSize = true;
            this.LabelNo9.Location = new System.Drawing.Point(600, 485);
            this.LabelNo9.Name = "LabelNo9";
            this.LabelNo9.Size = new System.Drawing.Size(61, 24);
            this.LabelNo9.TabIndex = 64;
            this.LabelNo9.Text = "NO 9 :\r\n1100  2800";
            this.LabelNo9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP9
            // 
            this.textBoxPP9.Location = new System.Drawing.Point(901, 482);
            this.textBoxPP9.Name = "textBoxPP9";
            this.textBoxPP9.ReadOnly = true;
            this.textBoxPP9.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP9.TabIndex = 62;
            this.textBoxPP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP9
            // 
            this.textBoxGP9.Location = new System.Drawing.Point(751, 506);
            this.textBoxGP9.Name = "textBoxGP9";
            this.textBoxGP9.ReadOnly = true;
            this.textBoxGP9.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP9.TabIndex = 61;
            this.textBoxGP9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar9
            // 
            this.trackBar9.Enabled = false;
            this.trackBar9.Location = new System.Drawing.Point(677, 482);
            this.trackBar9.Maximum = 2800;
            this.trackBar9.Minimum = 1100;
            this.trackBar9.Name = "trackBar9";
            this.trackBar9.Size = new System.Drawing.Size(201, 45);
            this.trackBar9.TabIndex = 63;
            this.trackBar9.Value = 1100;
            this.trackBar9.Scroll += new System.EventHandler(this.trackBar9_Scroll);
            // 
            // textBoxPP8
            // 
            this.textBoxPP8.Location = new System.Drawing.Point(901, 437);
            this.textBoxPP8.Name = "textBoxPP8";
            this.textBoxPP8.ReadOnly = true;
            this.textBoxPP8.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP8.TabIndex = 58;
            this.textBoxPP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP8
            // 
            this.textBoxGP8.Location = new System.Drawing.Point(751, 458);
            this.textBoxGP8.Name = "textBoxGP8";
            this.textBoxGP8.ReadOnly = true;
            this.textBoxGP8.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP8.TabIndex = 57;
            this.textBoxGP8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar8
            // 
            this.trackBar8.Enabled = false;
            this.trackBar8.Location = new System.Drawing.Point(677, 434);
            this.trackBar8.Maximum = 3000;
            this.trackBar8.Minimum = 1500;
            this.trackBar8.Name = "trackBar8";
            this.trackBar8.Size = new System.Drawing.Size(201, 45);
            this.trackBar8.TabIndex = 59;
            this.trackBar8.Value = 1500;
            this.trackBar8.Scroll += new System.EventHandler(this.trackBar8_Scroll);
            // 
            // LabelNo7
            // 
            this.LabelNo7.AutoSize = true;
            this.LabelNo7.Location = new System.Drawing.Point(600, 383);
            this.LabelNo7.Name = "LabelNo7";
            this.LabelNo7.Size = new System.Drawing.Size(51, 24);
            this.LabelNo7.TabIndex = 56;
            this.LabelNo7.Text = "NO 7 :\r\n800 2600";
            this.LabelNo7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP7
            // 
            this.textBoxPP7.Location = new System.Drawing.Point(901, 386);
            this.textBoxPP7.Name = "textBoxPP7";
            this.textBoxPP7.ReadOnly = true;
            this.textBoxPP7.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP7.TabIndex = 54;
            this.textBoxPP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP7
            // 
            this.textBoxGP7.Location = new System.Drawing.Point(751, 407);
            this.textBoxGP7.Name = "textBoxGP7";
            this.textBoxGP7.ReadOnly = true;
            this.textBoxGP7.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP7.TabIndex = 53;
            this.textBoxGP7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar7
            // 
            this.trackBar7.Enabled = false;
            this.trackBar7.Location = new System.Drawing.Point(677, 383);
            this.trackBar7.Maximum = 2600;
            this.trackBar7.Minimum = 800;
            this.trackBar7.Name = "trackBar7";
            this.trackBar7.Size = new System.Drawing.Size(201, 45);
            this.trackBar7.TabIndex = 55;
            this.trackBar7.Value = 800;
            this.trackBar7.Scroll += new System.EventHandler(this.trackBar7_Scroll);
            // 
            // LabelNo12
            // 
            this.LabelNo12.AutoSize = true;
            this.LabelNo12.Location = new System.Drawing.Point(600, 647);
            this.LabelNo12.Name = "LabelNo12";
            this.LabelNo12.Size = new System.Drawing.Size(57, 24);
            this.LabelNo12.TabIndex = 76;
            this.LabelNo12.Text = "NO 12 :\r\n1500 2000";
            this.LabelNo12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP12
            // 
            this.textBoxPP12.Location = new System.Drawing.Point(901, 644);
            this.textBoxPP12.Name = "textBoxPP12";
            this.textBoxPP12.ReadOnly = true;
            this.textBoxPP12.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP12.TabIndex = 74;
            this.textBoxPP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP12
            // 
            this.textBoxGP12.Location = new System.Drawing.Point(751, 668);
            this.textBoxGP12.Name = "textBoxGP12";
            this.textBoxGP12.ReadOnly = true;
            this.textBoxGP12.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP12.TabIndex = 73;
            this.textBoxGP12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar12
            // 
            this.trackBar12.Enabled = false;
            this.trackBar12.Location = new System.Drawing.Point(677, 644);
            this.trackBar12.Maximum = 2100;
            this.trackBar12.Minimum = 1500;
            this.trackBar12.Name = "trackBar12";
            this.trackBar12.Size = new System.Drawing.Size(201, 45);
            this.trackBar12.TabIndex = 75;
            this.trackBar12.Value = 1500;
            this.trackBar12.Scroll += new System.EventHandler(this.trackBar12_Scroll);
            // 
            // LabelNo11
            // 
            this.LabelNo11.AutoSize = true;
            this.LabelNo11.Location = new System.Drawing.Point(600, 605);
            this.LabelNo11.Name = "LabelNo11";
            this.LabelNo11.Size = new System.Drawing.Size(57, 24);
            this.LabelNo11.TabIndex = 72;
            this.LabelNo11.Text = "NO 11 :\r\n1100 2900";
            this.LabelNo11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP11
            // 
            this.textBoxPP11.Location = new System.Drawing.Point(901, 602);
            this.textBoxPP11.Name = "textBoxPP11";
            this.textBoxPP11.ReadOnly = true;
            this.textBoxPP11.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP11.TabIndex = 70;
            this.textBoxPP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP11
            // 
            this.textBoxGP11.Location = new System.Drawing.Point(751, 626);
            this.textBoxGP11.Name = "textBoxGP11";
            this.textBoxGP11.ReadOnly = true;
            this.textBoxGP11.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP11.TabIndex = 69;
            this.textBoxGP11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar11
            // 
            this.trackBar11.Enabled = false;
            this.trackBar11.Location = new System.Drawing.Point(677, 599);
            this.trackBar11.Maximum = 2900;
            this.trackBar11.Minimum = 1100;
            this.trackBar11.Name = "trackBar11";
            this.trackBar11.Size = new System.Drawing.Size(201, 45);
            this.trackBar11.TabIndex = 71;
            this.trackBar11.Value = 1100;
            this.trackBar11.Scroll += new System.EventHandler(this.trackBar11_Scroll);
            // 
            // LabelNo10
            // 
            this.LabelNo10.AutoSize = true;
            this.LabelNo10.Location = new System.Drawing.Point(600, 532);
            this.LabelNo10.Name = "LabelNo10";
            this.LabelNo10.Size = new System.Drawing.Size(57, 24);
            this.LabelNo10.TabIndex = 68;
            this.LabelNo10.Text = "NO 10 :\r\n1600 2400";
            this.LabelNo10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxPP10
            // 
            this.textBoxPP10.Location = new System.Drawing.Point(901, 529);
            this.textBoxPP10.Name = "textBoxPP10";
            this.textBoxPP10.ReadOnly = true;
            this.textBoxPP10.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP10.TabIndex = 66;
            this.textBoxPP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP10
            // 
            this.textBoxGP10.Location = new System.Drawing.Point(751, 550);
            this.textBoxGP10.Name = "textBoxGP10";
            this.textBoxGP10.ReadOnly = true;
            this.textBoxGP10.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP10.TabIndex = 65;
            this.textBoxGP10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBar10
            // 
            this.trackBar10.Enabled = false;
            this.trackBar10.Location = new System.Drawing.Point(677, 526);
            this.trackBar10.Maximum = 2400;
            this.trackBar10.Minimum = 1600;
            this.trackBar10.Name = "trackBar10";
            this.trackBar10.Size = new System.Drawing.Size(201, 45);
            this.trackBar10.TabIndex = 67;
            this.trackBar10.Value = 1600;
            this.trackBar10.Scroll += new System.EventHandler(this.trackBar10_Scroll);
            // 
            // textBoxC8
            // 
            this.textBoxC8.Location = new System.Drawing.Point(264, 446);
            this.textBoxC8.Multiline = true;
            this.textBoxC8.Name = "textBoxC8";
            this.textBoxC8.ReadOnly = true;
            this.textBoxC8.Size = new System.Drawing.Size(260, 34);
            this.textBoxC8.TabIndex = 77;
            // 
            // LabelNo1
            // 
            this.LabelNo1.AutoSize = true;
            this.LabelNo1.Location = new System.Drawing.Point(600, 114);
            this.LabelNo1.Name = "LabelNo1";
            this.LabelNo1.Size = new System.Drawing.Size(51, 24);
            this.LabelNo1.TabIndex = 78;
            this.LabelNo1.Text = "NO 1 :\r\n900 2800\r\n";
            this.LabelNo1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LabelNo2
            // 
            this.LabelNo2.AutoSize = true;
            this.LabelNo2.Location = new System.Drawing.Point(600, 157);
            this.LabelNo2.Name = "LabelNo2";
            this.LabelNo2.Size = new System.Drawing.Size(57, 24);
            this.LabelNo2.TabIndex = 79;
            this.LabelNo2.Text = "NO 2 :\r\n1800 2900\r\n";
            this.LabelNo2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LabelNo3
            // 
            this.LabelNo3.AutoSize = true;
            this.LabelNo3.Location = new System.Drawing.Point(600, 194);
            this.LabelNo3.Name = "LabelNo3";
            this.LabelNo3.Size = new System.Drawing.Size(57, 24);
            this.LabelNo3.TabIndex = 80;
            this.LabelNo3.Text = "NO 3 :\r\n1200 3000";
            this.LabelNo3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LabelNo8
            // 
            this.LabelNo8.AutoSize = true;
            this.LabelNo8.Location = new System.Drawing.Point(600, 437);
            this.LabelNo8.Name = "LabelNo8";
            this.LabelNo8.Size = new System.Drawing.Size(61, 24);
            this.LabelNo8.TabIndex = 81;
            this.LabelNo8.Text = "NO 8 :\r\n1500  3000\r\n";
            this.LabelNo8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxGP3
            // 
            this.textBoxGP3.Location = new System.Drawing.Point(751, 212);
            this.textBoxGP3.Name = "textBoxGP3";
            this.textBoxGP3.ReadOnly = true;
            this.textBoxGP3.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP3.TabIndex = 84;
            this.textBoxGP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP2
            // 
            this.textBoxGP2.Location = new System.Drawing.Point(751, 172);
            this.textBoxGP2.Name = "textBoxGP2";
            this.textBoxGP2.ReadOnly = true;
            this.textBoxGP2.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP2.TabIndex = 83;
            this.textBoxGP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGP1
            // 
            this.textBoxGP1.Location = new System.Drawing.Point(751, 130);
            this.textBoxGP1.Name = "textBoxGP1";
            this.textBoxGP1.ReadOnly = true;
            this.textBoxGP1.Size = new System.Drawing.Size(45, 21);
            this.textBoxGP1.TabIndex = 82;
            this.textBoxGP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPP3
            // 
            this.textBoxPP3.Location = new System.Drawing.Point(902, 191);
            this.textBoxPP3.Name = "textBoxPP3";
            this.textBoxPP3.ReadOnly = true;
            this.textBoxPP3.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP3.TabIndex = 87;
            this.textBoxPP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPP2
            // 
            this.textBoxPP2.Location = new System.Drawing.Point(902, 154);
            this.textBoxPP2.Name = "textBoxPP2";
            this.textBoxPP2.ReadOnly = true;
            this.textBoxPP2.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP2.TabIndex = 86;
            this.textBoxPP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPP1
            // 
            this.textBoxPP1.Location = new System.Drawing.Point(902, 111);
            this.textBoxPP1.Name = "textBoxPP1";
            this.textBoxPP1.ReadOnly = true;
            this.textBoxPP1.Size = new System.Drawing.Size(48, 21);
            this.textBoxPP1.TabIndex = 85;
            this.textBoxPP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonBulkWritePosition
            // 
            this.buttonBulkWritePosition.Location = new System.Drawing.Point(688, 22);
            this.buttonBulkWritePosition.Name = "buttonBulkWritePosition";
            this.buttonBulkWritePosition.Size = new System.Drawing.Size(174, 23);
            this.buttonBulkWritePosition.TabIndex = 88;
            this.buttonBulkWritePosition.Text = "모터위치 한번에 변경";
            this.buttonBulkWritePosition.UseVisualStyleBackColor = true;
            this.buttonBulkWritePosition.Click += new System.EventHandler(this.buttonBulkWritePosition_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1139, 736);
            this.Controls.Add(this.buttonBulkWritePosition);
            this.Controls.Add(this.textBoxPP3);
            this.Controls.Add(this.textBoxPP2);
            this.Controls.Add(this.textBoxPP1);
            this.Controls.Add(this.textBoxGP3);
            this.Controls.Add(this.textBoxGP2);
            this.Controls.Add(this.textBoxGP1);
            this.Controls.Add(this.LabelNo8);
            this.Controls.Add(this.LabelNo3);
            this.Controls.Add(this.LabelNo2);
            this.Controls.Add(this.LabelNo1);
            this.Controls.Add(this.textBoxC8);
            this.Controls.Add(this.LabelNo11);
            this.Controls.Add(this.textBoxPP11);
            this.Controls.Add(this.textBoxGP11);
            this.Controls.Add(this.trackBar11);
            this.Controls.Add(this.LabelNo10);
            this.Controls.Add(this.textBoxPP10);
            this.Controls.Add(this.textBoxGP10);
            this.Controls.Add(this.LabelNo9);
            this.Controls.Add(this.textBoxPP9);
            this.Controls.Add(this.textBoxGP9);
            this.Controls.Add(this.trackBar9);
            this.Controls.Add(this.textBoxPP8);
            this.Controls.Add(this.textBoxGP8);
            this.Controls.Add(this.trackBar8);
            this.Controls.Add(this.LabelNo7);
            this.Controls.Add(this.textBoxPP7);
            this.Controls.Add(this.textBoxGP7);
            this.Controls.Add(this.trackBar7);
            this.Controls.Add(this.LabelNo6);
            this.Controls.Add(this.textBoxPP6);
            this.Controls.Add(this.textBoxGP6);
            this.Controls.Add(this.trackBar6);
            this.Controls.Add(this.LabelNo5);
            this.Controls.Add(this.textBoxPP5);
            this.Controls.Add(this.textBoxGP5);
            this.Controls.Add(this.LabelNo4);
            this.Controls.Add(this.textBoxPP4);
            this.Controls.Add(this.textBoxGP4);
            this.Controls.Add(this.trackBar4);
            this.Controls.Add(this.textBoxC12);
            this.Controls.Add(this.textBoxC11);
            this.Controls.Add(this.textBoxC10);
            this.Controls.Add(this.textBoxC9);
            this.Controls.Add(this.textBoxC7);
            this.Controls.Add(this.textBoxC6);
            this.Controls.Add(this.textBoxC5);
            this.Controls.Add(this.textBoxC4);
            this.Controls.Add(this.textBoxC3);
            this.Controls.Add(this.trackBar3);
            this.Controls.Add(this.trackBar2);
            this.Controls.Add(this.textBoxC2);
            this.Controls.Add(this.LabelMotorNumber);
            this.Controls.Add(this.LabelMotorPresentPosition);
            this.Controls.Add(this.LabelMortorGoalPosition);
            this.Controls.Add(this.labelConnect);
            this.Controls.Add(this.labelBaudrate);
            this.Controls.Add(this.labelOpenPort);
            this.Controls.Add(this.textBoxC1);
            this.Controls.Add(this.textBoxBaudrate);
            this.Controls.Add(this.textBoxOpenPort);
            this.Controls.Add(this.buttonPortConnet);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.trackBar5);
            this.Controls.Add(this.trackBar10);
            this.Controls.Add(this.LabelNo12);
            this.Controls.Add(this.textBoxPP12);
            this.Controls.Add(this.textBoxGP12);
            this.Controls.Add(this.trackBar12);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonPortConnet;
        private System.Windows.Forms.TextBox textBoxOpenPort;
        private System.Windows.Forms.TextBox textBoxBaudrate;
        private System.Windows.Forms.TextBox textBoxC1;
        private System.Windows.Forms.Label labelOpenPort;
        private System.Windows.Forms.Label labelBaudrate;
        private System.Windows.Forms.Label labelConnect;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label LabelMortorGoalPosition;
        private System.Windows.Forms.Label LabelMotorPresentPosition;
        private System.Windows.Forms.Label LabelMotorNumber;
        private System.Windows.Forms.TextBox textBoxC2;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.TextBox textBoxC3;
        private System.Windows.Forms.TextBox textBoxC4;
        private System.Windows.Forms.TextBox textBoxC5;
        private System.Windows.Forms.TextBox textBoxC6;
        private System.Windows.Forms.TextBox textBoxC7;
        private System.Windows.Forms.TextBox textBoxC9;
        private System.Windows.Forms.TextBox textBoxC10;
        private System.Windows.Forms.TextBox textBoxC11;
        private System.Windows.Forms.TextBox textBoxC12;
        private System.Windows.Forms.Label LabelNo4;
        private System.Windows.Forms.TextBox textBoxPP4;
        private System.Windows.Forms.TextBox textBoxGP4;
        private System.Windows.Forms.TrackBar trackBar4;
        private System.Windows.Forms.Label LabelNo6;
        private System.Windows.Forms.TextBox textBoxPP6;
        private System.Windows.Forms.TextBox textBoxGP6;
        private System.Windows.Forms.TrackBar trackBar6;
        private System.Windows.Forms.Label LabelNo5;
        private System.Windows.Forms.TextBox textBoxPP5;
        private System.Windows.Forms.TextBox textBoxGP5;
        private System.Windows.Forms.TrackBar trackBar5;
        private System.Windows.Forms.Label LabelNo9;
        private System.Windows.Forms.TextBox textBoxPP9;
        private System.Windows.Forms.TextBox textBoxGP9;
        private System.Windows.Forms.TrackBar trackBar9;
        private System.Windows.Forms.TextBox textBoxPP8;
        private System.Windows.Forms.TextBox textBoxGP8;
        private System.Windows.Forms.TrackBar trackBar8;
        private System.Windows.Forms.Label LabelNo7;
        private System.Windows.Forms.TextBox textBoxPP7;
        private System.Windows.Forms.TextBox textBoxGP7;
        private System.Windows.Forms.TrackBar trackBar7;
        private System.Windows.Forms.Label LabelNo12;
        private System.Windows.Forms.TextBox textBoxPP12;
        private System.Windows.Forms.TextBox textBoxGP12;
        private System.Windows.Forms.TrackBar trackBar12;
        private System.Windows.Forms.Label LabelNo11;
        private System.Windows.Forms.TextBox textBoxPP11;
        private System.Windows.Forms.TextBox textBoxGP11;
        private System.Windows.Forms.TrackBar trackBar11;
        private System.Windows.Forms.Label LabelNo10;
        private System.Windows.Forms.TextBox textBoxPP10;
        private System.Windows.Forms.TextBox textBoxGP10;
        private System.Windows.Forms.TrackBar trackBar10;
        private System.Windows.Forms.TextBox textBoxC8;
        private System.Windows.Forms.Label LabelNo1;
        private System.Windows.Forms.Label LabelNo2;
        private System.Windows.Forms.Label LabelNo3;
        private System.Windows.Forms.Label LabelNo8;
        private System.Windows.Forms.TextBox textBoxGP3;
        private System.Windows.Forms.TextBox textBoxGP2;
        private System.Windows.Forms.TextBox textBoxGP1;
        private System.Windows.Forms.TextBox textBoxPP3;
        private System.Windows.Forms.TextBox textBoxPP2;
        private System.Windows.Forms.TextBox textBoxPP1;
        public System.Windows.Forms.Button buttonBulkWritePosition;
    }
}

