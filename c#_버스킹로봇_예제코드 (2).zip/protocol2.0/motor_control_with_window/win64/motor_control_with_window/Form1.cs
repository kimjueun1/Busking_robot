﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using dynamixel_sdk;
using System.Threading;

namespace motor_control_with_window
{
    public partial class Form1 : Form
    {
        // Control table address
        public const int ADDR_PRO_TORQUE_ENABLE = 64;                 // Control table address is different in Dynamixel model
        public const int ADDR_PRO_GOAL_POSITION = 116;
        public const int ADDR_PRO_PRESENT_POSITION = 132;

        // Data Byte Length
        public const int LEN_PRO_GOAL_POSITION = 4;
        public const int LEN_PRO_PRESENT_POSITION = 4;

        // Protocol version
        public const int PROTOCOL_VERSION = 2;                   // See which protocol version is used in the Dynamixel

        // Default setting
        public const int DXL_ID = 1;                          // Dynamixel ID: 1
        public const int BAUDRATE = 1000000;
        public const string DEVICENAME = "COM5";              // Check which port is being used on your controller
                                                              // ex) Windows: "COM1"   Linux: "/dev/ttyUSB0" Mac: "/dev/tty.usbserial-*"

        public const int TORQUE_ENABLE = 1;                   // Value for enabling the torque
        public const int TORQUE_DISABLE = 0;                   // Value for disabling the torque
        //public const int DXL_MINIMUM_POSITION_VALUE = 0;                   // Dynamixel will rotate between this value
        //public const int DXL_MAXIMUM_POSITION_VALUE = 2040;                // and this value (note that the Dynamixel would not move when the position value is out of movable range. Check e-manual about the range of the Dynamixel you use.)
        //public const int DXL_MOVING_STATUS_THRESHOLD = 20;                  // Dynamixel moving status threshold

        //public const byte ESC_ASCII_VALUE = 0x1b;

        public const int COMM_SUCCESS = 0;                   // Communication Success result value
        public const int COMM_TX_FAIL = -1001;               // Communication Tx Failed

        int port_num;
        int groupwrite_num;
        int groupread_num;

        public int dxl_present_position1;
        public int dxl_present_position2;
        public int dxl_present_position3;
        public int dxl_present_position4;
        public int dxl_present_position5;

        public int dxl_present_position6;
        public int dxl_present_position7;
        public int dxl_present_position8;
        public int dxl_present_position9;
        public int dxl_present_position10;

        public int dxl_present_position11;
        public int dxl_present_position12;

        int dxl_comm_result = COMM_TX_FAIL;
        byte dxl_error = 0;                                                   // Dynamixel error
        bool dxl_addparam_result = false;                                     // AddParam result
        bool dxl_getdata_result = false;                                      // GetParam result


        public Form1()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            // Initialize PortHandler Structs
            // Set the port path
            // Get methods and members of PortHandlerLinux or PortHandlerWindows
            port_num = dynamixel.portHandler(DEVICENAME);

            // Initialize PacketHandler Structs
            dynamixel.packetHandler();

            // Initialize GroupBulkWrite Struct
            groupwrite_num = dynamixel.groupBulkWrite(port_num, PROTOCOL_VERSION);

            // Initialize Groupbulkread Structs
            groupread_num = dynamixel.groupBulkRead(port_num, PROTOCOL_VERSION);



            // Open port
            if (dynamixel.openPort(port_num))
            {
                textBoxOpenPort.Text = "Succeeded to open the port!";
            }
            else
            {
                textBoxOpenPort.Text = "Failed to open the port!\n";
                textBoxOpenPort.Text = "Press any key to terminate...";
                return;
            }

            // Set port baudrate
            if (dynamixel.setBaudRate(port_num, BAUDRATE))
            {
                textBoxBaudrate.Text = "Succeeded to change the baudrate!";
            }
            else
            {
                textBoxBaudrate.Text = "Failed to change the baudrate!";
                textBoxBaudrate.Text = "Press any key to terminate...";
                return;
            }

            // Enable Dynamixel Torque
            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, DXL_ID, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC1.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC1.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC1.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 2, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC2.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC2.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC2.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 3, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC3.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC3.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC3.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 4, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC4.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC4.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC4.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 5, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC5.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC5.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC5.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 6, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC6.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC6.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC6.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 7, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC7.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC7.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC7.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 8, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC8.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC8.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC8.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 9, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC9.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC9.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC9.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 10, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC10.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC10.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC10.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 11, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC11.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC11.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC11.Text = "Dynamixel has been successfully connected";
            }

            dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, 12, ADDR_PRO_TORQUE_ENABLE, TORQUE_ENABLE);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
            {
                textBoxC12.Text = Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result));
            }
            else if ((dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)) != 0)
            {
                textBoxC12.Text = Marshal.PtrToStringAnsi(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error));
            }
            else
            {
                textBoxC12.Text = "Dynamixel has been successfully connected";
            }


            //Read AddParamatar Part

            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 1, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 1 ] groupBulkRead addparam failed","GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 2, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 2 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 3, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 3 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 4, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 4 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 5, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 5 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }


            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 6, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 6 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 7, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 7 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 8, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 8 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 9, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 9 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 10, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 10 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }


            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 11, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 11 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkReadAddParam(groupread_num, 12, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 12 ] groupBulkRead addparam failed", "GroupBulkReadError");
                Close();
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //trackBar Part
        
            trackBar1.Enabled = true;
            trackBar2.Enabled = true;
            trackBar3.Enabled = true;
            trackBar4.Enabled = true;
            trackBar6.Enabled = true;

            trackBar5.Enabled = true;
            trackBar7.Enabled = true;
            trackBar8.Enabled = true;
            trackBar9.Enabled = true;
            trackBar10.Enabled = true;

            trackBar11.Enabled = true;
            trackBar12.Enabled = true;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //present_position & trackBar.Value Part 버튼누르고 현재 위치로 트랙바 값 초기화 파트

            dynamixel.groupBulkReadTxRxPacket(groupread_num);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
                MessageBox.Show(Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result)),"Error");


            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 1, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 1] groupBulkRead getdata failed","Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 2, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 2] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 3, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 3] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 4, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 4] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 5, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 5] groupBulkRead getdata failed", "Error");
                Close();
            }


            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 6, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 6] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 7, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 7] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 8, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 8] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 9, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 9] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 10, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 10] groupBulkRead getdata failed", "Error");
                Close();
            }


            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 11, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 11] groupBulkRead getdata failed", "Error");
                Close();
            }
            dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 12, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            if (dxl_getdata_result != true)
            {
                MessageBox.Show("[ID: 12] groupBulkRead getdata failed", "Error");
                Close();
            }

            dxl_present_position1 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 1, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position2 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 2, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position3 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 3, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position4 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 4, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position5 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 5, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);

            dxl_present_position6 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 6, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position7 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 7, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position8 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 8, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position9 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 9, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position10 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 10, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);

            dxl_present_position11 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 11, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
            dxl_present_position12 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 12, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);

            trackBar1.Value = dxl_present_position1;
            trackBar2.Value = dxl_present_position2;
            trackBar3.Value = dxl_present_position3;
            trackBar4.Value = dxl_present_position4;
            trackBar5.Value = dxl_present_position5;

            trackBar6.Value = dxl_present_position6;
            trackBar7.Value = dxl_present_position7;
            trackBar8.Value = dxl_present_position8;
            trackBar9.Value = dxl_present_position9;
            trackBar10.Value = dxl_present_position10;

            trackBar11.Value = dxl_present_position11;
            trackBar12.Value = dxl_present_position12;

            
            textBoxGP1.Text = trackBar1.Value.ToString();
            textBoxGP2.Text = trackBar2.Value.ToString();
            textBoxGP3.Text = trackBar3.Value.ToString();
            textBoxGP4.Text = trackBar4.Value.ToString();
            textBoxGP5.Text = trackBar6.Value.ToString();

            textBoxGP6.Text = trackBar5.Value.ToString();
            textBoxGP7.Text = trackBar7.Value.ToString();
            textBoxGP8.Text = trackBar8.Value.ToString();
            textBoxGP9.Text = trackBar9.Value.ToString();
            textBoxGP10.Text = trackBar10.Value.ToString();

            textBoxGP11.Text = trackBar11.Value.ToString();
            textBoxGP12.Text = trackBar12.Value.ToString();

            new Thread(new ThreadStart(Thread_Test1)).Start();
        }

        delegate void SendText(Control ctl, String text);

        private void CSendText(Control ctl, String text)
        {
            if (ctl.InvokeRequired)
                ctl.Invoke(new SendText(CSendText), ctl, text);
            else
                ctl.Text = text;
        }

        public void Thread_Test1()
        {
            while (true)
            {
                dynamixel.groupBulkReadTxRxPacket(groupread_num);
                if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
                    MessageBox.Show(Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result)), "Error");


                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 1, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 1] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 2, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 2] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 3, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 3] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 4, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 4] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 5, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 5] groupBulkRead getdata failed", "Error");
                    Close();
                }


                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 6, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 6] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 7, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 7] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 8, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 8] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 9, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 9] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 10, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 10] groupBulkRead getdata failed", "Error");
                    Close();
                }


                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 11, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 11] groupBulkRead getdata failed", "Error");
                    Close();
                }
                dxl_getdata_result = dynamixel.groupBulkReadIsAvailable(groupread_num, 12, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                if (dxl_getdata_result != true)
                {
                    MessageBox.Show("[ID: 12] groupBulkRead getdata failed", "Error");
                    Close();
                }

                dxl_present_position1 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 1, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP1, dxl_present_position1.ToString());
                dxl_present_position2 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 2, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP2, dxl_present_position2.ToString());
                dxl_present_position3 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 3, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP3, dxl_present_position3.ToString());
                dxl_present_position4 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 4, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP4, dxl_present_position4.ToString());
                dxl_present_position5 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 5, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP5, dxl_present_position5.ToString());

                dxl_present_position6 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 6, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP6, dxl_present_position6.ToString());
                dxl_present_position7 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 7, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP7, dxl_present_position7.ToString());
                dxl_present_position8 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 8, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP8, dxl_present_position8.ToString());
                dxl_present_position9 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 9, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP9, dxl_present_position9.ToString());
                dxl_present_position10 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 10, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP10, dxl_present_position10.ToString());

                dxl_present_position11 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 11, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP11, dxl_present_position11.ToString());
                dxl_present_position12 = (Int32)dynamixel.groupBulkReadGetData(groupread_num, 12, ADDR_PRO_PRESENT_POSITION, LEN_PRO_PRESENT_POSITION);
                CSendText(textBoxPP12, dxl_present_position12.ToString());

                // 0.1초 단위
                Thread.Sleep(100);
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBoxGP1.Text = trackBar1.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, DXL_ID, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar1.Value);
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            textBoxGP2.Text = trackBar2.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 2, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar2.Value);
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            textBoxGP3.Text = trackBar3.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 3, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar3.Value);
        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {
            textBoxGP4.Text = trackBar4.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 4, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar4.Value);
        }
        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            textBoxGP5.Text = trackBar5.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 5, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar5.Value);
        }
        private void trackBar6_Scroll(object sender, EventArgs e)
        {
            textBoxGP6.Text = trackBar6.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 6, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar6.Value);
        }
        private void trackBar7_Scroll(object sender, EventArgs e)
        {
            textBoxGP7.Text = trackBar7.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 7, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar7.Value);
        }
        private void trackBar8_Scroll(object sender, EventArgs e)
        {
            textBoxGP8.Text = trackBar8.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 8, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar8.Value);
        }
        private void trackBar9_Scroll(object sender, EventArgs e)
        {
            textBoxGP9.Text = trackBar9.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 9, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar9.Value);
        }

        private void trackBar10_Scroll(object sender, EventArgs e)
        {
            textBoxGP10.Text = trackBar10.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 10, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar10.Value);
        }
        private void trackBar11_Scroll(object sender, EventArgs e)
        {
            textBoxGP11.Text = trackBar11.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 11, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar11.Value);
        }
        private void trackBar12_Scroll(object sender, EventArgs e)
        {
            textBoxGP12.Text = trackBar12.Value.ToString();

            // Write goal position
            //dynamixel.write4ByteTxRx(port_num, PROTOCOL_VERSION, 12, ADDR_PRO_GOAL_POSITION, (UInt32)trackBar12.Value);
        }

        private void buttonBulkWritePosition_Click(object sender, EventArgs e)
        {
            //////////////////////////////////////////////////////////////////////////////////////////
            // Add parameter storage for Dynamixe goal position
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 1, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar1.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 1] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 2, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar2.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 2] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 3, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar3.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 3] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 4, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar4.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 4] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 5, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar5.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 5] groupBulkWrite addparam failed", "Error");
                Close();
            }
            

            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 6, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar6.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 6] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 7, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar7.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 7] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 8, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar8.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 8] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 9, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar9.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 9] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 10, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar10.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 10] groupBulkWrite addparam failed", "Error");
                Close();
            }


            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 11, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar11.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 11] groupBulkWrite addparam failed", "Error");
                Close();
            }
            dxl_addparam_result = dynamixel.groupBulkWriteAddParam(groupwrite_num, 12, ADDR_PRO_GOAL_POSITION, LEN_PRO_GOAL_POSITION, (UInt32)trackBar12.Value, LEN_PRO_GOAL_POSITION);
            if (dxl_addparam_result != true)
            {
                MessageBox.Show("[ID: 12] groupBulkWrite addparam failed", "Error");
                Close();
            }

            // Bulkwrite goal position and LED value
            dynamixel.groupBulkWriteTxPacket(groupwrite_num);
            if ((dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)) != COMM_SUCCESS)
                MessageBox.Show(Marshal.PtrToStringAnsi(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result)),"Error");

            // Clear bulkwrite parameter storage
            dynamixel.groupBulkWriteClearParam(groupwrite_num);

        }
    }
}
